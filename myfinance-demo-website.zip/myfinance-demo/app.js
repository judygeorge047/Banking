const KEY = "myfinance_demo_v1";
const DEMO_EMAIL = "demo@myfinance.local";
const DEMO_PASSWORD = "demo1234";

const $ = (id) => document.getElementById(id);
const state = JSON.parse(localStorage.getItem(KEY) || JSON.stringify({
  users: [], currentUser: null
}));

function save(){ localStorage.setItem(KEY, JSON.stringify(state)); }
function money(n){ return new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"}).format(Number(n)||0); }
function today(){ return new Date().toISOString().slice(0,10); }
function uid(){ return crypto.randomUUID ? crypto.randomUUID() : Date.now()+"-"+Math.random(); }

function demoUser(){
  return {
    id:"demo-user",
    name:"Demo User",
    email:DEMO_EMAIL,
    password:DEMO_PASSWORD,
    openingBalance:1238.93,
    transactions:[
      {id:"t1",description:"Salary",amount:2500,type:"deposit",date:"2026-08-01"},
      {id:"t2",description:"Coffee Shop",amount:6.50,type:"withdrawal",date:"2026-08-03"},
      {id:"t3",description:"Grocery Market",amount:73.27,type:"withdrawal",date:"2026-08-05"},
      {id:"t4",description:"Freelance Payment",amount:450,type:"deposit",date:"2026-08-08"}
    ]
  };
}
function ensureDemo(){
  if(!state.users.some(u=>u.id==="demo-user")) state.users.push(demoUser());
  save();
}
ensureDemo();

function user(){ return state.users.find(u=>u.id===state.currentUser) || null; }
function balance(u){ return Number(u.openingBalance||0) + u.transactions.reduce((sum,t)=>sum+(t.type==="deposit"?Number(t.amount):-Number(t.amount)),0); }

function showView(id){
  document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));
  $(id).classList.add("active");
  window.scrollTo({top:0,behavior:"smooth"});
}
function toast(msg){
  const el=$("toast"); el.textContent=msg; el.classList.add("show");
  clearTimeout(window.__toast); window.__toast=setTimeout(()=>el.classList.remove("show"),2600);
}

let signup=false;
function renderAuth(){
  $("authTitle").textContent=signup?"Create your demo account":"Sign in to your demo";
  $("authSubtitle").textContent=signup?"Create an account stored locally in this browser.":"Use the demo account or sign in to a local account.";
  $("authSubmit").textContent=signup?"Create account":"Sign in";
  $("nameField").classList.toggle("hidden",!signup);
  $("toggleAuth").textContent=signup?"Already have an account? Sign in":"Need an account? Create one";
  $("passwordInput").autocomplete=signup?"new-password":"current-password";
}

function renderDashboard(){
  const u=user(); if(!u){ showView("landingView"); return; }
  const b=balance(u);
  $("welcomeName").textContent=`Hello, ${u.name}`;
  $("balanceValue").textContent=money(b);
  $("heroBalance").textContent=money(b);
  $("newBalanceInput").value=Number(u.openingBalance||0).toFixed(2);
  const deposits=u.transactions.filter(t=>t.type==="deposit").reduce((s,t)=>s+Number(t.amount),0);
  const withdrawals=u.transactions.filter(t=>t.type==="withdrawal").reduce((s,t)=>s+Number(t.amount),0);
  $("depositTotal").textContent=money(deposits);
  $("withdrawalTotal").textContent=money(withdrawals);
  $("transactionCount").textContent=u.transactions.length;

  const list=$("transactionsList");
  if(!u.transactions.length){ list.innerHTML='<div class="empty">No demo transactions yet.</div>'; return; }
  list.innerHTML=[...u.transactions].sort((a,b)=>new Date(b.date)-new Date(a.date)).map(t=>`
    <div class="transaction">
      <div><strong>${escapeHtml(t.description)}</strong><small>${formatDate(t.date)} · ${t.type}</small></div>
      <strong class="amount ${t.type}">${t.type==="deposit"?"+":"-"}${money(t.amount)}</strong>
      <div class="row-actions"><button data-edit="${t.id}" aria-label="Edit transaction">Edit</button><button data-delete="${t.id}" aria-label="Delete transaction">Delete</button></div>
    </div>`).join("");
  list.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>openEdit(b.dataset.edit));
  list.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>deleteTransaction(b.dataset.delete));
}
function escapeHtml(s){ const d=document.createElement("div"); d.textContent=s; return d.innerHTML; }
function formatDate(s){ return new Date(s+"T12:00:00").toLocaleDateString(undefined,{year:"numeric",month:"short",day:"numeric"}); }

$("authBtn").onclick=()=>{ signup=false; renderAuth(); showView("authView"); };
$("landingLoginBtn").onclick=$("authBtn").onclick;
$("findFitBtn").onclick=()=>document.getElementById("features").scrollIntoView({behavior:"smooth"});
$("homeBtn").onclick=()=>showView("landingView");
$("toggleAuth").onclick=()=>{ signup=!signup; renderAuth(); };
$("demoLoginBtn").onclick=()=>{ state.currentUser="demo-user"; save(); renderDashboard(); showView("dashboardView"); toast("Demo account opened"); };

$("authForm").onsubmit=(e)=>{
  e.preventDefault();
  const email=$("emailInput").value.trim().toLowerCase();
  const password=$("passwordInput").value;
  const name=$("nameInput").value.trim();
  if(signup){
    if(!name){ toast("Please enter your name"); return; }
    if(state.users.some(u=>u.email===email)){ toast("An account with this email already exists"); return; }
    const newUser={id:uid(),name,email,password,openingBalance:0,transactions:[]};
    state.users.push(newUser); state.currentUser=newUser.id; save();
    renderDashboard(); showView("dashboardView"); toast("Demo account created");
  }else{
    const found=state.users.find(u=>u.email===email && u.password===password);
    if(!found){ toast("Incorrect email or password"); return; }
    state.currentUser=found.id; save(); renderDashboard(); showView("dashboardView"); toast("Signed in");
  }
};

$("logoutBtn").onclick=()=>{ state.currentUser=null; save(); showView("landingView"); toast("Signed out"); };
$("editBalanceBtn").onclick=()=>$("balanceDialog").showModal();
$("closeBalanceDialog").onclick=()=>$("balanceDialog").close();
$("balanceForm").onsubmit=(e)=>{
  e.preventDefault();
  const u=user(), n=Number($("newBalanceInput").value);
  if(!Number.isFinite(n)){ toast("Enter a valid amount"); return; }
  u.openingBalance=n; save(); $("balanceDialog").close(); renderDashboard(); toast("Demo balance updated");
};

$("transactionDate").value=today();
$("transactionForm").onsubmit=(e)=>{
  e.preventDefault();
  const u=user(), amount=Number($("transactionAmount").value);
  if(!amount || amount<=0){ toast("Enter an amount greater than zero"); return; }
  u.transactions.push({id:uid(),description:$("transactionDescription").value.trim(),amount,type:$("transactionType").value,date:$("transactionDate").value});
  save(); e.target.reset(); $("transactionDate").value=today(); renderDashboard(); toast("Transaction added");
};

function openEdit(id){
  const t=user().transactions.find(x=>x.id===id); if(!t)return;
  $("editTransactionId").value=t.id; $("editDescription").value=t.description; $("editAmount").value=t.amount;
  $("editType").value=t.type; $("editDate").value=t.date; $("editDialog").showModal();
}
$("closeEditDialog").onclick=()=>$("editDialog").close();
$("editTransactionForm").onsubmit=(e)=>{
  e.preventDefault(); const u=user(), t=u.transactions.find(x=>x.id===$("editTransactionId").value);
  const amount=Number($("editAmount").value); if(!t||!amount||amount<=0){toast("Enter a valid amount");return;}
  t.description=$("editDescription").value.trim(); t.amount=amount; t.type=$("editType").value; t.date=$("editDate").value;
  save(); $("editDialog").close(); renderDashboard(); toast("Transaction updated");
};
function deleteTransaction(id){
  if(!confirm("Delete this demo transaction?")) return;
  const u=user(); u.transactions=u.transactions.filter(t=>t.id!==id); save(); renderDashboard(); toast("Transaction deleted");
}
$("resetDemoBtn").onclick=()=>{
  const u=user(); if(u.id!=="demo-user"){toast("Reset is available only for the built-in demo account");return;}
  if(!confirm("Reset the demo account to its original sample data?"))return;
  Object.assign(u,demoUser()); save(); renderDashboard(); toast("Demo data reset");
};

if(state.currentUser){ renderDashboard(); showView("dashboardView"); } else { renderAuth(); }
