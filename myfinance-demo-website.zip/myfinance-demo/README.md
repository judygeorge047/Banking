# MyFinance Demo

A safe, fictional banking-style demo inspired by the layout of the supplied reference image.

## Features
- Landing page
- Local demo sign-up and sign-in
- Built-in demo account
- Editable simulated opening balance
- Add deposit and withdrawal transactions
- Edit and delete transactions
- Running balance and totals
- Responsive mobile layout
- Browser localStorage persistence

## Demo login
Email: demo@myfinance.local
Password: demo1234

## Run locally
Open `index.html` in a browser.

For a local development server, from this folder run:
`python -m http.server 8000`

Then open:
`http://localhost:8000`

## Important
This project is a fictional demo only. It is not a real bank, does not process real money, and must not be used to collect real banking credentials or payment information.

## Deploy
You can upload these files to a static hosting provider such as GitHub Pages, Netlify, Cloudflare Pages, or Vercel to obtain a public shareable link.
